echo HOST_IP=`hostname -i` > .env
echo MYSQL_CONF=`pwd`/mysql >> .env
docker-compose up -d